import { createClient } from 'redis';

// Redis Cloud connection details
const redisClient = createClient({
    password: 'DVEEOHq61WFyul48qhvgEifBshyk9Ayt',
    socket: {
        host: 'redis-14145.c57.us-east-1-4.ec2.redns.redis-cloud.com',
        port: 14145
    }
});


// Connect to Redis Cloud
redisClient.connect().catch(console.error);

// Publish a message to the "notifications" channel
function sendNotification(eventData) {
    redisClient.publish('notifications', JSON.stringify(eventData));
}

// Example notification
const newNotification = {
    type: 'like',
    postID: 12345,
    user: 'JohnDoe',
    message: 'JohnDoe liked your post!'
};

// Send the example notification
sendNotification(newNotification);
