// src/schema.js
const { GraphQLObjectType, GraphQLString, GraphQLID, GraphQLList, GraphQLSchema, GraphQLNonNull } = require('graphql');

// Mock database for tasks
let tasks = [
  { id: '1', title: 'Task 1', description: 'First task' },
  { id: '2', title: 'Task 2', description: 'Second task' },
];

// Task Type
const TaskType = new GraphQLObjectType({
  name: 'Task',
  fields: () => ({
    id: { type: GraphQLID },
    title: { type: GraphQLString },
    description: { type: GraphQLString },
  }),
});

// Root Query
const RootQuery = new GraphQLObjectType({
  name: 'RootQueryType',
  fields: {
    task: {
      type: TaskType,
      args: { id: { type: GraphQLID } },
      resolve(parent, args) {
        return tasks.find((task) => task.id === args.id);
      },
    },
    tasks: {
      type: new GraphQLList(TaskType),
      resolve() {
        return tasks;
      },
    },
  },
});

// Mutations
const Mutation = new GraphQLObjectType({
  name: 'Mutation',
  fields: {
    addTask: {
      type: TaskType,
      args: {
        title: { type: new GraphQLNonNull(GraphQLString) },
        description: { type: GraphQLString },
      },
      resolve(parent, args) {
        const newTask = { id: `${tasks.length + 1}`, title: args.title, description: args.description };
        tasks.push(newTask);
        return newTask;
      },
    },
    deleteTask: {
      type: TaskType,
      args: {
        id: { type: new GraphQLNonNull(GraphQLID) },
      },
      resolve(parent, args) {
        const taskIndex = tasks.findIndex((task) => task.id === args.id);
        if (taskIndex === -1) throw new Error('Task not found');
        const deletedTask = tasks.splice(taskIndex, 1)[0];
        return deletedTask;
      },
    },
    updateTask: {
      type: TaskType,
      args: {
        id: { type: new GraphQLNonNull(GraphQLID) },
        title: { type: GraphQLString },
        description: { type: GraphQLString },
      },
      resolve(parent, args) {
        const task = tasks.find((task) => task.id === args.id);
        if (!task) throw new Error('Task not found');
        if (args.title) task.title = args.title;
        if (args.description) task.description = args.description;
        return task;
      },
    },
  },
});

module.exports = new GraphQLSchema({
  query: RootQuery,
  mutation: Mutation,
});
