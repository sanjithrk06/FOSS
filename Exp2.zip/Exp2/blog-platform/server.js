const express = require('express');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const fs = require('fs');

dotenv.config();
const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(bodyParser.json());

// User and Post data arrays
let users = [];
let posts = [];

// Load data from file if exists
if (fs.existsSync('data.txt')) {
    const data = fs.readFileSync('data.txt', 'utf-8').split('\n');
    data.forEach(line => {
        const [type, ...info] = line.split(',');
        if (type === 'user') users.push({ username: info[0], password: info[1] });
        else if (type === 'post') posts.push({ title: info[0], content: info[1], author: info[2] });
    });
}

// Routes
app.use('/api', require('./routes/userRoutes')(users));
app.use('/api', require('./routes/postRoutes')(posts, users));

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
