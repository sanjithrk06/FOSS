const fs = require('fs');

module.exports = (posts, users) => {
    const router = require('express').Router();
    const auth = require('../middleware/auth');

    // Create a post
    router.post('/posts', auth, (req, res) => {
        const { title, content } = req.body;
        const post = { title, content, author: req.user.username };
        posts.push(post);
        fs.appendFileSync('data.txt', `post,${title},${content},${req.user.username}\n`);
        res.status(201).send(post);
    });

    // Get all posts
    router.get('/posts', (req, res) => {
        res.json(posts);
    });

    // Edit a post
    router.put('/posts/:title', auth, (req, res) => {
        const { title } = req.params;
        const { content } = req.body;
        const postIndex = posts.findIndex(post => post.title === title);

        if (postIndex === -1) return res.status(404).send('Post not found');

        posts[postIndex].content = content;

        // Re-write posts to file
        fs.writeFileSync('data.txt', posts.map(p => `post,${p.title},${p.content},${p.author}`).join('\n') + '\n');

        res.json(posts[postIndex]);
    });

    // Delete a post
    router.delete('/posts/:title', auth, (req, res) => {
        const { title } = req.params;
        const postIndex = posts.findIndex(post => post.title === title);
    
        if (postIndex === -1) return res.status(404).send('Post not found');
    
        posts.splice(postIndex, 1);
    
        // Re-write posts to file
        fs.writeFileSync('data.txt', posts.map(p => `post,${p.title},${p.content},${p.author}`).join('\n') + '\n');
    
        res.status(200).send({ message: 'Post successfully deleted' });
    });

    return router;
};
